import joblib, pandas as pd

model = joblib.load("models/fraud_model.pkl")

sample = pd.DataFrame({
    "amount":[500],
    "oldbalanceOrg":[1200],
    "newbalanceOrig":[700],
    "transaction_type":[1]
})

print(model.predict(sample))
