import pandas as pd
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE

class DataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.sm = SMOTE(random_state=42)

    def clean(self, df):
        df = df.dropna()
        df = df[df.amount > 0]
        return df

    def scale(self, X):
        return self.scaler.fit_transform(X)

    def balance(self, X, y):
        return self.sm.fit_resample(X, y)
