from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import joblib

class FraudModel:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=300, random_state=42)

    def train(self, X, y):
        self.model.fit(X, y)

    def evaluate(self, X_test, y_test):
        preds = self.model.predict(X_test)
        print(confusion_matrix(y_test, preds))
        print(classification_report(y_test, preds))

    def save(self, path="models/fraud_model.pkl"):
        joblib.dump(self.model, path)
