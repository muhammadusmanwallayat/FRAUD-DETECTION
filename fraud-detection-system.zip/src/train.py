from utils import load_dataset, split
from data_prep import DataPreprocessor
from model import FraudModel

df = load_dataset("data/sample_transactions.csv")

dp = DataPreprocessor()
df = dp.clean(df)

X_train, X_test, y_train, y_test = split(df)
X_train = dp.scale(X_train)
X_test = dp.scaler.transform(X_test)
X_train, y_train = dp.balance(X_train, y_train)

fm = FraudModel()
fm.train(X_train, y_train)
fm.evaluate(X_test, y_test)
fm.save()
